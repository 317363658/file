function initial() {
	mui.init({
		pullRefresh: {
			container: '#pullrefresh',
			down: {
				callback: pulldownRefresh
			},
			up: {
				contentrefresh: '正在加载...',
				callback: pullupRefresh
			}
		}
	});
	
	//初始化加载
	plusLoad();
	
	//点击链接进入详情页
	clickOpenDetail();
}

/**
 * 下拉刷新具体业务实现
 */
function pulldownRefresh() {
	setTimeout(function() {
		var table = document.body.querySelector('#imgList');
		var cells = document.body.querySelectorAll('.mui-table-view-cell');
		for(var i = cells.length, len = i + 3; i < len; i++) {
			var li = document.createElement('li');
			var _div = document.createElement('div');
			_div.innerHTML = '<div class="mui-card"><div class="mui-card-content"><img src="../img/1.png" style="width:100%"/></div><div class="mui-card-footer"><div class="mui-left">富满电子在深交所上市</div><div class="mui-right">2017-07-06</div></div></div>';
			//下拉刷新，新纪录插到最前面；
			table.insertBefore(_div, table.firstChild);
		}
		mui('#pullrefresh').pullRefresh().endPulldownToRefresh(); //refresh completed
	}, 1500);
}
var count = 0;

/**
 * 上拉加载具体业务实现
 */
function pullupRefresh() {
	setTimeout(function() {
		mui('#pullrefresh').pullRefresh().endPullupToRefresh((++count > 2)); //参数为true代表没有更多数据了。
		var table = document.body.querySelector('#imgList');
		var cells = document.body.querySelectorAll('.mui-card');
		for(var i = cells.length, len = i + 2; i < len; i++) {
			var _div = document.createElement('div');
			_div.innerHTML = '<div class="mui-card"><div class="mui-card-content"><img src="../img/1.png" style="width:100%"/></div><div class="mui-card-footer"><div class="mui-left">富满电子在深交所上市</div><div class="mui-right">2017-07-06</div></div></div>';
			table.appendChild(_div);
		}
	}, 1500);
}

function plusLoad(){
	if(mui.os.plus) {
		mui.plusReady(function() {
			setTimeout(function() {
				mui('#pullrefresh').pullRefresh().pullupLoading();
			}, 1000);
	
		});
	} else {
		mui.ready(function() {
			mui('#pullrefresh').pullRefresh().pullupLoading();
		});
	}
}

//点击列表连接 进入详情
function clickOpenDetail() {
	mui('#pullrefresh').on('tap', '.mui-card-footer', function() {
		var titleId = this.getAttribute('dataid');
		openDetail(titleId);
	});
}

//打开详情页
function openDetail(titleId){
	//浏览器打开方式
	
	//真机打开方式
	_nativeOpenHtml('webApp/common/view/detail-link/detail.html');
	
	//传递数据
	localStorage.setItem("targetId", titleId);
}