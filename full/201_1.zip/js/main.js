// 页面入口
function initial() {
	//页面初始化
	mui.init();

	//数据获取
	getData();

	//事件绑定
	bindEvents();

}

//获取所有数据接口
function getData() {
	getRuleData();
	getPublicTask();
	getNoPublicRule();
}

//绑定全部事件入口
function bindEvents() {
	_showArticle(); //点击显示更多文章
	clickMoreList(); //点击更多列表
	clickOpenDetail(); //打开更多的列表
}

//获取IPO相关规则数据
function getRuleData() {
	mui.ajax('http://192.168.10.254:6789/aservice/Json/search.do?type=cmsList', {
		data: {},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			var datas = JSON.parse(data.json);
			showRule('发行、上市规则（IPO相关规则）', datas, "#ipoRule", 'list/list');
		},
		error: function(xhr, type, errorThrown) {
			var errorJson = {
				xhr: xhr,
				type: type,
				errorThrown: errorThrown
			};
			console.log(errorJson);
		}
	});
}

//获取上市流程数据
function getPublicTask() {
	mui.ajax('http://192.168.10.254:6789/aservice/Json/search.do?type=cmsArticle', {
		data: {},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			var datas = JSON.parse(data.json);
			showRule('发行上市流程', datas, "#publicTask", 'article/article');
		},
		error: function(xhr, type, errorThrown) {
			var errorJson = {
				xhr: xhr,
				type: type,
				errorThrown: errorThrown
			};
			console.log(errorJson);
		}
	});
}

//（不包括上市之后相关规则）
function getNoPublicRule() {
	mui.ajax('http://192.168.10.254:6789/aservice/Json/search.do?type=cmsArticle', {
		data: {},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			var datas = JSON.parse(data.json);
			showRule('不包括上市之后相关规则', datas, "#PublicRule", 'article/article');
		},
		error: function(xhr, type, errorThrown) {
			var errorJson = {
				xhr: xhr,
				type: type,
				errorThrown: errorThrown
			};
			console.log(errorJson);
		}
	});
}

//实例化模块。 titile ： 模块名称，data：模块数据,ele:模块要加载到的容器（#id  .class），templateId:模板ID
function showRule(title, data, ele, templateId) {
	var dataJson = {
		title: title ? title : "",
		titleId: title ? title : "", //暂时测试使用
		//		titleId:data.titleId?data.titleId:'',//真是数据使用
		data: data.data
	};
	var htmlStr = '';
	templateId ? htmlStr = template(templateId, dataJson) : mui.alert('模块ID不能为空', '渲染模板报错');// jshint ignore:line
	ele ? mui(ele)[0].innerHTML = htmlStr : mui.alert('容器ID不能为空', '渲染模板报错');// jshint ignore:line
}

function clickMoreList() {
	//点击更多列表
	mui('#content').on('tap', '.moreList', function() {
		//获取id
		var titleId = this.getAttribute("titleId");
		openMoreList(titleId);
	});
}

//点击列表连接 进入详情
function clickOpenDetail() {
	mui('#content').on('tap', '.detailBtn', function() {
		var titleId = this.getAttribute('dataid');
		openDetail(titleId);
	});
}

//打开更多的列表
function openMoreList(titleId) {
	
	//真机打开方式
	_nativeOpenHtml('webApp/common/view/detail-link/pullrefresh_main.html');
	
	//传递数据
	localStorage.setItem("targetId", titleId);
}

//打开详情页
function openDetail(titleId) {
	//浏览器打开方式
	
	//真机打开方式
	_nativeOpenHtml('webApp/common/view/detail-link/detail.html');
	
	//传递数据
	localStorage.setItem("targetId", titleId);
}