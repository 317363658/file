//判断运行环境
var _browser={
    versions:function(){
        var u = navigator.userAgent, app = navigator.appVersion;
        return {         //移动终端浏览器版本信息
            trident: u.indexOf('Trident') > -1, //IE内核
            presto: u.indexOf('Presto') > -1, //opera内核
            webKit: u.indexOf('AppleWebKit') > -1, //苹果、谷歌内核
            gecko: u.indexOf('Gecko') > -1 && u.indexOf('KHTML') == -1, //火狐内核
            mobile: !!u.match(/AppleWebKit.*Mobile.*/), //是否为移动终端
            ios: !!u.match(/\(i[^;]+;( U;)? CPU.+Mac OS X/), //ios终端
            android: u.indexOf('Android') > -1 || u.indexOf('Linux') > -1, //android终端或uc浏览器
            iPhone: u.indexOf('iPhone') > -1 , //是否为iPhone或者QQHD浏览器
            iPad: u.indexOf('iPad') > -1, //是否iPad
            webApp: u.indexOf('Safari') == -1 //是否web应该程序，没有头部与底部
        };
    }(),
    language:(navigator.browserLanguage || navigator.language).toLowerCase()
};

//点击显示更多文章
var _showArticle = function() {
	mui("#content").on('tap', '.showArticle', function() {
		var parentMain = this.parentNode.parentNode.parentNode;
		var mainHeight, articleHeight;
		if(this.classList.contains('mui-icon-arrowdown')) {
			mainHeight = articleHeight = 'auto';
			this.classList.add("mui-icon-arrowup");
			this.classList.remove("mui-icon-arrowdown");
		} else {
			//			mainHeight = '260px';
			articleHeight = '210px';
			this.classList.remove("mui-icon-arrowup");
			this.classList.add("mui-icon-arrowdown");
		}
		//		parentMain.style.height = mainHeight;
		parentMain.lastElementChild.style.height = articleHeight;

		//滚动到指定位置
		var parentMainTop = parentMain.parentNode.offsetTop;
		document.body.scrollTop = parentMainTop - 100;
	});
};

/*手机端打开页面 */
var _nativeOpenHtml = function(url) {
	if(_browser.versions.android) {
		android.href(url); //打开另一个h5页面
	} else if(_browser.versions.ios) {
		iosHref(url);
	}
};

/*手机端关闭页面*/
var _callBack = function() {
	if(_browser.versions.android) {
		android.finish();
	} else if(_browser.versions.ios) {
		iosBack();
	} else {
		history.back();
	}
};

//设置缓存存储接口
var _nativeSetStorage = function(key, value) {
	if(_browser.versions.android) {
		android.setItem(key, value);
	} else if(_browser.versions.ios) {
		ios_set(key, value);
	}
};

//获取缓存存储接口
var _nativeGetStorage = function(key) {
	if(_browser.versions.android) {
		return android.getItem(key);
	} else if(_browser.versions.ios) {
		ios_get(key);
	}
};
