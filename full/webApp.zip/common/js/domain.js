// 兼容ios和android的调用页面方法
function _initMethod(method) {
    if(_browser.versions.ios) {
        var loop = setInterval(function(){
            if(iosLog) {
                method();
                clearInterval(loop);
            }
        },200);
    } else{
        method();
    }
}