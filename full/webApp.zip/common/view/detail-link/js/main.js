// 页面入口
window.initial = function() {
	//页面初始化
	mui.init();

	//数据获取
	getData();

	//关闭页面
	closeWin();
};

function getData() {
	var id = '840594b2-5c8f-404d-a5d1-5a57946e9a9d';
	getDetailData(id);
}

function closeWin() {
	//关闭窗口
	mui('header').on('tap', '.mui-action-back', function() {
		_callBack();
	});
}

// 图文连接
function getDetailData(id) {
	mui.ajax('https://mdev.szse.cn/api/newsdetail?newsId=' + id, {
		data: {},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			document.getElementById('title').innerText = data.data.category;
			document.getElementById('title-article').innerText = data.data.title;
			document.getElementById('detail').innerHTML = data.data.content;
			document.getElementById('describe').innerText = "时间： " + data.data.publishdate;
		},
		error: function(xhr, type, errorThrown) {
			var errorJson = {
				xhr: xhr,
				type: type,
				errorThrown: errorThrown
			};
			console.log(errorJson);
		}
	});
}