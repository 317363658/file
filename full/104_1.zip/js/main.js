// 页面入口
function initial() {
	//页面初始化
	mui.init({
		gestureConfig: { //双击置顶
			doubletap: true
		}
	});

	mui('.mui-scroll-wrapper').scroll({
		deceleration: 0.0005, //flick 减速系数，系数越大，滚动速度越慢，滚动距离越小，默认值0.0006
		scrollY: true, //是否竖向滚动
		scrollX: false, //是否横向滚动
		startX: 0, //初始化时滚动至x
		startY: 0, //初始化时滚动至y
		indicators: true, //是否显示滚动条
		bounce: false //是否启用回弹
	});

	//数据获取
	getData();

	//事件绑定
	bindEvents();

}

//获取所有数据接口
function getData() {
	//本所要闻
	getPresentation();
	//新闻发布会
	getNewsInfo();
}

//绑定全部事件入口
function bindEvents() {
	_showArticle(); //点击显示更多文章
	clickMoreList(); //点击更多列表
	clickOpenDetail(); //点击列表连接 进入详情
}

//证券市场导报
function getNewsInfo() {
	mui.ajax('http://192.168.10.254:6789/aservice/Json/search.do?type=cmsList', {
		data: {},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			var datas = JSON.parse(data.json);
			showRule('证券市场导报', datas, "#news", 'list/list');
		},
		error: function(xhr, type, errorThrown) {
			var errorJson = {
				xhr: xhr,
				type: type,
				errorThrown: errorThrown
			};
			mui.alert(xhr.responseURL, type + ' - ' + errorThrown);
		}
	});
}

//研究报告
function getPresentation() {
	mui.ajax('http://192.168.10.254:6789/aservice/Json/search.do?type=cmsList', {
		data: {},
		dataType: 'json', //服务器返回json格式数据
		type: 'get', //HTTP请求类型
		timeout: 10000, //超时时间设置为10秒；
		success: function(data) {
			var datas = JSON.parse(data.json);
			showRule('研究报告', datas, "#presentation", 'list/list');
		},
		error: function(xhr, type, errorThrown) {
			var errorJson = {
				xhr: xhr,
				type: type,
				errorThrown: errorThrown
			};
			mui.alert(xhr.responseURL, type + ' - ' + errorThrown);
		}
	});
}

//实例化模块。 titile ： 模块名称，data：模块数据,ele:模块要加载到的容器（#id  .class），templateId:模板ID
function showRule(title, data, ele, templateId) {
	var dataJson = {
		title: title ? title : "",
		titleId: title ? title : "", //暂时测试使用
		//		titleId:data.titleId?data.titleId:'',//真是数据使用
		data: data.data
	};
	var htmlStr = '';
	templateId ? htmlStr = template(templateId, dataJson) : mui.alert('模块ID不能为空', '渲染模板报错'); // jshint ignore:line
	ele ? mui(ele)[0].innerHTML = htmlStr : mui.alert('容器ID不能为空', '渲染模板报错'); // jshint ignore:line
}

//点击更多列表
function clickMoreList() {
	mui('#content').on('tap', '.moreList', function() {
		//获取id
		var titleId = this.getAttribute("titleId");
		openMoreList(titleId);
	});
}

//点击列表连接 进入详情
function clickOpenDetail() {
	mui('#content').on('tap', '.detailBtn', function() {
		var titleId = this.getAttribute('dataid');
		openDetail(titleId);
	});
}

//打开更多的列表
function openMoreList(titleId) {
	//浏览器测试用
	localStorage.setItem("targetId", titleId);
	//打开页面
	_nativeOpenHtml('webApp/common/view/pullrefresh-link/pullrefresh_main.html');
}

//打开详情页
function openDetail(titleId) {
	//浏览器测试用
	localStorage.setItem("targetId", titleId);
	//打开页面
	_nativeOpenHtml('webApp/common/view/detail-link/detail.html');
}