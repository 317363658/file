/**
 * Created by bqwu on 2017/4/14.
 */

/***echart数据 star***/
/**绘制分线图 star**/
    //格式化改后台获取的分时图数据
    function formatMinuteData(data, index){
        var result = [];
        for(var i = 0, len = data.length; i < len; i++){
            result.push(data[i][index]);
        }
        return result;
    }

    //分时图对象
    var minuteCharts = function(url,myChart,dynamicUrl,callback){
        this.option = {
            url:url,
            myChart:myChart,
            allData:'',
            dynamicUrl:dynamicUrl,
            setIntervalMinute:'',
            callback:callback,
            chartOption:{
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#777',
                            width: 1,
                            opacity: 0.5
                        }
                    },
                    backgroundColor: 'rgba(245, 245, 245, 0.8)',
                    borderWidth: 1,
                    borderColor: '#ccc',
                    padding: 10,
                    textStyle: {
                        color: '#000'
                    },
                    position: function (pos, params, el, elRect, size) {
                        var obj = {top: 10};
                        obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30;
                        return obj;
                    },
                    extraCssText: 'width: 170px',
                    formatter:function(params){
                    }
                },
                axisPointer: {
                    link: {xAxisIndex: 'all'},
                    label: {
                        backgroundColor: '#777'
                    }
                },
                dataZoom: [{
                    type: 'slider',
                    xAxisIndex: [0, 1],
                    realtime: false,
                    start: 0,
                    top: 0,
                    height: 0,
                    handleIcon: 'M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '120%'
                }, {
                    type: 'inside',
                    xAxisIndex: [0, 1],
                    start: 40,
                    end: 70,
                    top: 30,
                    height: 20
                }],
                xAxis: [{
                    type: 'category',
                    data: this.xAxisData(),
                    scale: false,
                    boundaryGap: true,
                    splitLine: { show: false },
                    axisLabel:{
                        interval:function(index,value){
                            if(value == '09:30' || value == '10:30' || value == '14:00'|| value == '15:00' || value == '11:30/13:00'){
                                return value;
                            }
                        }
                    },
                    axisTick:{show:false},
                    axisLine: { lineStyle: { color: '#777' } }
                },{
                    type: 'category',
                    gridIndex: 1,
                    data:this.xAxisData(),
                    axisTick:{show:false},
                    axisLabel: {show: false}

                }],
                yAxis: [{
                    scale: true,
                    splitNumber: 2,
                    axisLine: { lineStyle: { color: '#777' } },
                    splitLine: { show: true },
                    axisTick: { show: false },
                    axisLabel: {
                        inside: true,
                        formatter: '{value}\n'
                    }
                }, {
                    scale: true,
                    gridIndex: 1,
                    splitNumber: 2,
                    axisLine: { lineStyle: { color: '#777' } },
                    axisLabel: {show: false},
                    axisTick: {show: false},
                    splitLine: {show: true}
                }],
                grid: [{
                    left: 15,
                    right: 15,
                    top: 30,
                    height: 150
                }, {
                    left: 15,
                    right: 15,
                    height: 80,
                    top: 210
                }],
                series: [{
                    name: '总手',
                    type: 'bar',
                    xAxisIndex: 1,
                    yAxisIndex: 1,
                    animation:false,
                    itemStyle: {
                        normal: {
                            color: function(params) {
                            }
                        }
                    },
                    data: []
                },{
                    name: '价格',
                    type: 'line',
                    data: [],
                    smooth: true,
                    showSymbol:false,
                    animation:false,
                    lineStyle: {
                        normal: {
                            width: 1,
                            color:'#1e8dd5'
                        }
                    },
                    areaStyle: {//阴影块
                        normal: {
                            color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                offset: 0,
                                color: 'rgb(136, 201, 243)'
                            }])
                        }
                    }
                }, {
                    name: '均价',
                    type: 'line',
                    data: [],
                    smooth: true,
                    showSymbol:false,
                    animation:false,
                    symbol:'none',
                    lineStyle: {
                        normal: {
                            width: 1,
                            color:"#fcbf1c"
                        }
                    }
                }]
            }
        };
    };
    //设置charts option
    minuteCharts.prototype.setChartsOption = function(data){
        var _this = this;
        _this.option.allData = data.data.data;
        //分时图数据
        _this.option.chartOption.series[0].data = formatMinuteData(_this.option.allData,4);//交易量
        _this.option.chartOption.series[1].data = formatMinuteData(_this.option.allData,2);//价格
        _this.option.chartOption.series[2].data = formatMinuteData(_this.option.allData,3);//平均价格
        _this.option.chartOption.series[0].itemStyle.normal.color = function(params) {
            var colorList;
            var listData = (_this.option.allData[params.dataIndex]);
            if (listData[2] > listData[1]) {
                colorList = '#f00';
            } else if(listData[2]<listData[1]) {
                colorList = '#14b143';
            }else if(listData[2] == listData[1]){
                colorList = '#e3e3e3';
            }
            return colorList;
        };
        _this.option.chartOption.tooltip.formatter = function(params){
            var content ="<p>时间："+_this.option.allData[params[0].dataIndex][0]+"</p>"
                +"<p>价格："+_this.option.allData[params[0].dataIndex][2]+"</p>"
                +"<p>均价："+_this.option.allData[params[0].dataIndex][3]+"</p>"
                +"<p>交易量："+_this.option.allData[params[0].dataIndex][4]+"</p>"
                +"<p>涨幅："+Math.round(_this.option.allData[params[0].dataIndex][5]*100)/100 +"%"+"</p>";
            return content;
        }
        this.option.myChart.setOption(this.option.chartOption);

    };
    //请求后台数据。
    minuteCharts.prototype.getData = function(){
        var _this = this;
        $.ajax({
            type:'GET',
            url:_this.option.url,
            dataType:'json',
            success:function(data){
                _this.setChartsOption(data);
                _this.option.callback &&  _this.option.callback();
                if(_this.option.dynamicUrl != ''){
                    _this.dynamicData();
                }
            }
        })
    };
    //设置X轴坐标。
    minuteCharts.prototype.xAxisData = function(){
        var amStarDate = new Date();
        amStarDate.setHours(9);
        amStarDate.setMinutes(30);
        var amHours = amStarDate.getHours()>9?amStarDate.getHours():'0'+amStarDate.getHours();
        var amMinute = amStarDate.getMinutes()>9?amStarDate.getMinutes():'0'+amStarDate.getMinutes();
        var pmStarDate = new Date();
        pmStarDate.setHours(13);
        pmStarDate.setMinutes(1);
        var pmHours = pmStarDate.getHours()>9?pmStarDate.getHours():'0'+pmStarDate.getHours();
        var pmMinute = pmStarDate.getMinutes()>9?pmStarDate.getMinutes():'0'+pmStarDate.getMinutes();
        var dateX = [];
        dateX.push(amHours+':'+amMinute);
        for(var i = 0; i < 60*2; i++){
            amStarDate.setMinutes(amStarDate.getMinutes()+1);
            amHours = amStarDate.getHours()>9?amStarDate.getHours():'0'+amStarDate.getHours();
            amMinute = amStarDate.getMinutes()>9?amStarDate.getMinutes():'0'+amStarDate.getMinutes();
            if(amHours == 11 && amMinute == 30){
                dateX.push(amHours+':'+amMinute + '/' + '13:00');
            }else {
                dateX.push(amHours+':'+amMinute);
            }

        }
        dateX.push(pmHours+':'+pmMinute);
        for(var o = 0; o < 60*2-1; o++){
            pmStarDate.setMinutes(pmStarDate.getMinutes()+1);
            pmHours = pmStarDate.getHours()>9?pmStarDate.getHours():'0'+pmStarDate.getHours();
            pmMinute = pmStarDate.getMinutes()>9?pmStarDate.getMinutes():'0'+pmStarDate.getMinutes();
            dateX.push(pmHours+':'+pmMinute);
        }
        return dateX;
    };
    //动态数据请求
    minuteCharts.prototype.dynamicData = function(){
        var _this = this;
        _this.option.setIntervalMinute = setInterval(function(){
            //$.ajax({
            //    type:'GET',
            //    url:_this.option.dynamicUrl,
            //    dataType:'json',
            //    success:function(data){
            //        var dynamicData = data.data.data;
            //        _this.option.allData.push(dynamicData);
            //        _this.option.chartOption.series[0].data.push(formatMinuteData(dynamicData,4));
            //        _this.option.chartOption.series[1].data.push(formatMinuteData(dynamicData,2));
            //        _this.option.chartOption.series[2].data.push(formatMinuteData(dynamicData,3));
            //        _this.option.myChart.setOption(_this.option.chartOption);
            //    }
            //})；
            _this.option.allData.push(["0937","18.20","18.00","18.20","1456844","0.1345"]);
            _this.option.chartOption.series[0].data.push('1456844');
            _this.option.chartOption.series[1].data.push((Math.random()*(18-17+1)+17).toFixed(2));
            _this.option.chartOption.series[2].data.push('18.20');
            myChart.setOption(_this.option.chartOption);
        },10000);
    };
    //停止动态数据请求。
    minuteCharts.prototype.stopDynamicData = function(){
        clearInterval(this.option.setIntervalMinute);
    };
    //实例化图表
    minuteCharts.prototype.initChart = function(){
        this.getData();
    };
/**绘制分线图 end**/

/**绘制五日图 star**/
    //五日图对象
    var fiveCharts = function(url,myChart,dynamicUrl,callback){
        this.option = {
            url:url,
            myChart:myChart,
            allData:'',
            dynamicUrl:dynamicUrl,
            setIntervalMinute:'',
            callback:callback,
            chartOption: {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#777',
                            width: 1,
                            opacity: 0.5
                        }
                    },
                    backgroundColor: 'rgba(245, 245, 245, 0.8)',
                    borderWidth: 1,
                    borderColor: '#ccc',
                    padding: 10,
                    textStyle: {
                        color: '#000'
                    },
                    position: function (pos, params, el, elRect, size) {
                        var obj = {top: 10};
                        obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30;
                        return obj;
                    },
                    extraCssText: 'width: 170px',
                    formatter:function(params){
                    }
                },
                axisPointer: {
                    link: [{xAxisIndex:[0,1]}]
                },
                grid: [{
                    left: 10,
                    right: 10,
                    top: 30,
                    height: 150
                }, {
                    left: 10,
                    right: 10,
                    height: 80,
                    top: 210
                }],
                xAxis: [
                    {
                        type: 'category',
                        data: this.xAxisData(),
                        axisLabel:{
                            interval:0,
                            formatter:function(value, index){

                            }
                        },
                        textStyle:{
                            align:'right'
                        },
                        axisLine:{show:true},
                        axisTick:{show:false},
                        splitLine:{
                            show:true,
                            interval:240
                        }
                    },
                    {

                        gridIndex: 1,
                        type: 'category',
                        data:  this.xAxisData(),
                        axisLabel:{
                            interval:240,
                            formatter:function(value, index){
                            }
                        },
                        axisLine:{show:true},
                        axisTick:{show:false},
                        splitLine:{
                            show:true,
                            interval:240
                        }
                    }
                ],
                yAxis: [
                    {
                        scale: true,
                        axisLine:{show:true},
                        axisTick:{show:false},
                        axisLabel:{
                            inside:true,
                            interval:2,
                            showMinLabel:false,
                            showMaxLabel:true
                        },
                        splitLine:false
                    },
                    {
                        scale: true,
                        gridIndex: 1,
                        axisLine:{show:true},
                        axisTick:{show:false},
                        axisLabel:{
                            inside:true,
                            interval:2,
                            showMinLabel:false,
                            showMaxLabel:true,
                            show:false
                        },
                        splitLine:false
                    }],
                series: [
                    {
                        name: '交易量',
                        type: 'bar',
                        xAxisIndex: 1,
                        yAxisIndex: 1,
                        animation:false,
                        itemStyle: {
                            normal: {
                                color: function(params) {
                                }
                            }
                        },
                        data: []
                    },
                    {
                        name: '价格',
                        type: 'line',
                        data:[],
                        showSymbol:false,
                        animation:false,
                        lineStyle: {
                            normal: {
                                width: 1,
                                color:'#1e8dd5'
                            }
                        },
                        areaStyle: {//阴影块
                            normal: {
                                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                                    offset: 0,
                                    color: 'rgb(136, 201, 243)'
                                }])
                            }
                        }

                    }

                ]
            }
        }
    };
    //请求后台数据。
    fiveCharts.prototype.getData = function(){
        var _this = this;
        $.ajax({
            type:'GET',
            url:this.option.url,
            dataType:'json',
            success:function(data){
                _this.setChartsOption(data);
                _this.option.callback && _this.option.callback();
                if(_this.option.dynamicUrl != ''){
                    _this.dynamicData();
                }
            },
            error:function(){
                alert('This is error! go away,Please!')
            }
        });
    };
    //设置charts option
    fiveCharts.prototype.setChartsOption = function(data){
        var _this = this;
        _this.option.allData = data.data;//总数据
        var priceData = data.price;//价格
        var dayData = data.dayData;//哪几天
        var volumeData = data.volume;//交易量
        _this.option.chartOption.series[1].data = priceData;
        _this.option.chartOption.series[0].data = volumeData;
        _this.option.chartOption.xAxis[0].axisLabel.formatter = function(value, index){
            if(index%120 == 0){
                if(index/120 % 2 == 1){
                    var str = dayData[parseInt(index/120/2)];
                    str = str.substring(5);
                    return str;
                }else{
                    return ''
                }
            }else {
                return ''
            }
        };
        _this.option.chartOption.tooltip.formatter = function(params){
            var tooltipData = _this.option.allData[params[0].dataIndex];
            if(tooltipData.length > 0){
                var content ="<p>日期："+tooltipData[5]+"</p>"
                    + "<p>时间："+tooltipData[6]+"</p>"
                    +"<p>开盘价："+tooltipData[0]+"</p>"
                    +"<p>价格："+tooltipData[1]+"</p>"
                    +"<p>均价："+tooltipData[2]+"</p>"
                    +"<p>交易量："+tooltipData[3]+"</p>"
                    +"<p>涨幅："+Math.round(tooltipData[4]*100)/100 +"%"+"</p>";
                return content;
            }
        };
        _this.option.chartOption.series[0].itemStyle.normal = {
            color: function(params) {
                var colorList;
                if (_this.option.allData[params.dataIndex][1]<_this.option.allData[params.dataIndex][0]) {
                    colorList = '#ef232a';
                } else {
                    colorList = '#14b143';
                }
                return colorList;
            }
        };//设置交易量涨跌颜色

        this.option.myChart.setOption(this.option.chartOption);
    };
    //设置X轴坐标。
    fiveCharts.prototype.xAxisData = function(){
        //dayNum代表几天，allMinute代码一天的分钟数
        function xArrFn(dayNum,allMinute){
            var result = [];
            for(var o = 0; o < dayNum*allMinute;o++){

                result.push(o)
            }
            return result;
        }
        return xArrFn(5,241);//241的原因是只要隔天 需要一个点来做分割线 对应返回来的数据‘-’
    };
    //动态数据请求
    fiveCharts.prototype.dynamicData = function(){
        var _this = this;
        _this.option.setIntervalMinute = setInterval(function(){
            //$.ajax({
            //    type:'GET',
            //    url:_this.option.dynamicUrl,
            //    dataType:'json',
            //    success:function(data){
            //        var dynamicData = data.data.data;
            //        _this.option.allData.push(dynamicData);
            //        _this.option.chartOption.series[0].data.push(formatMinuteData(dynamicData,4));
            //        _this.option.chartOption.series[1].data.push(formatMinuteData(dynamicData,2));
            //        _this.option.chartOption.series[2].data.push(formatMinuteData(dynamicData,3));
            //        _this.option.myChart.setOption(_this.option.chartOption);
            //    }
            //})；
        },10000);
    };
    //停止动态数据请求。
    fiveCharts.prototype.stopDynamicData = function(){
        clearInterval(this.option.setIntervalMinute);
    };
    //实例化图表
    fiveCharts.prototype.initChart = function(){
        this.getData();
    };
/**绘制五日图 end**/
/**绘制K线图 star**/
    //K图对象
    var KCharts = function(url,myChart,dynamicUrl,callback){
        this.option = {
            url:url,
            myChart:myChart,
            allData:'',
            dynamicUrl:dynamicUrl,
            setIntervalMinute:'',
            callback:callback,
            chartOption:  {
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        lineStyle: {
                            color: '#777',
                            width: 1,
                            opacity: 0.5
                        }
                    },
                    backgroundColor: 'rgba(245, 245, 245, 0.8)',
                    borderWidth: 1,
                    borderColor: '#ccc',
                    padding: 10,
                    textStyle: {
                        color: '#000'
                    },
                    position: function (pos, params, el, elRect, size) {
                        var obj = {top: 10};
                        obj[['left', 'right'][+(pos[0] < size.viewSize[0] / 2)]] = 30;
                        return obj;
                    },
                    extraCssText: 'width: 170px',
                    formatter:function(params){

                    }
                },
                axisPointer: {
                    link: {xAxisIndex: 'all'}
                },
                dataZoom: [{
                    type: 'slider',
                    xAxisIndex: [0, 1],
                    realtime: false,
                    start: 0,
                    top: 0,
                    height: 0,
                    handleIcon: 'M10.7,11.9H9.3c-4.9,0.3-8.8,4.4-8.8,9.4c0,5,3.9,9.1,8.8,9.4h1.3c4.9-0.3,8.8-4.4,8.8-9.4C19.5,16.3,15.6,12.2,10.7,11.9z M13.3,24.4H6.7V23h6.6V24.4z M13.3,19.6H6.7v-1.4h6.6V19.6z',
                    handleSize: '120%'
                }, {
                    type: 'inside',
                    xAxisIndex: [0, 1],
                    start: 40,
                    end: 70,
                    top: 30,
                    height: 20
                }],
                xAxis: [{
                    type: 'category',
                    data: [],
                    scale: true,
                    splitNumber: 20,
                    min: 'dataMin',
                    max: 'dataMax',
                    axisTick:{show:false},
                    axisLine: { lineStyle: { color: '#777' }},
                    axisLabel:{
                        textStyle:{
                            align:'left'
                        }
                    }

                },{
                    type: 'category',
                    gridIndex: 1,
                    data:[],
                    axisTick:{show:false},
                    axisLabel: {show: false}
                }],
                yAxis: [{
                    scale: true,
                    splitNumber: 2,
                    axisLine: { lineStyle: { color: '#777' } },
                    splitLine: { show: true },
                    axisTick: { show: false },
                    axisLabel: {
                        inside: true,
                        formatter: '{value}\n'
                    }
                }, {
                    scale: true,
                    gridIndex: 1,
                    splitNumber: 2,
                    axisLine: { lineStyle: { color: '#777' } },
                    axisLabel: {show: false},
                    axisTick: {show: false},
                    splitLine: {show: true}
                }],
                grid: [{
                    left: 10,
                    right: 10,
                    top: 30,
                    height: 150
                }, {
                    left: 10,
                    right: 10,
                    height: 80,
                    top: 210
                }],
                series: [{
                    name: '交易量',
                    type: 'bar',
                    xAxisIndex: 1,
                    yAxisIndex: 1,
                    animation:false,
                    itemStyle: {
                        normal: {
                            color: function(params) {

                            }
                        }
                    },
                    data: []
                }, {
                    type: 'candlestick',
                    name: '日K',
                    data: [],
                    showSymbol:false,
                    animation:false,
                    itemStyle: {
                        normal: {
                            color: '#ef232a',
                            color0: '#14b143',
                            borderColor: '#ef232a',
                            borderColor0: '#14b143'
                        },
                        emphasis: {
                            color: 'black',
                            color0: '#444',
                            borderColor: 'black',
                            borderColor0: '#444'
                        }
                    }
                }, {
                    name: 'MA5',
                    type: 'line',
                    data: [],
                    smooth: true,
                    animation:false,
                    showSymbol:false,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    }
                }, {
                    name: 'MA10',
                    type: 'line',
                    data: [],
                    smooth: true,
                    animation:false,
                    showSymbol:false,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    }
                }, {
                    name: 'MA30',
                    type: 'line',
                    data: [],
                    smooth: true,
                    animation:false,
                    showSymbol:false,
                    lineStyle: {
                        normal: {
                            width: 1
                        }
                    }
                }]
            }
        }
    };
    //请求后台数据。
    KCharts.prototype.getData = function(){
        var _this = this;
        $.ajax({
            type:'GET',
            url:this.option.url,
            dataType:'json',
            success:function(data){
                _this.setChartsOption(data);
                _this.option.callback && _this.option.callback();
                if(_this.option.dynamicUrl != ''){
                    _this.dynamicData();
                }
            },
            error:function(){
                alert('This is error! go away,Please!')
            }
        });
    };
    //设置charts option
    KCharts.prototype.setChartsOption = function(data){
        var _this = this;
        var KDates = data.dates;
        var KData = data.data;
        var KAmounts = data.volumns;
        var MA5Data = _this.calculateMA(5, KData);//5日前
        var MA10Data = _this.calculateMA(10, KData);//10日前
        var MA30Data = _this.calculateMA(30, KData);//30日前
        var MA5ToolTipValue,MA10ToolTipValue,MA30ToolTipValue;
        _this.option.chartOption.xAxis[0].data = KDates;//设置K线图 X轴坐标
        _this.option.chartOption.xAxis[1].data = KDates;//设置交易量 X轴坐标

        _this.option.chartOption.xAxis[0].data[KDates.length-1] = {value:' ',textStyle:{align : 'right',color: 'red'}};
        //console.log( _this.option.chartOption.xAxis[0].data[KDates.length-1]);

        _this.option.chartOption.series[0].data = KAmounts;//设置交易量数据
        _this.option.chartOption.series[1].data = KData;//设置蜡烛图数据
        _this.option.chartOption.series[2].data = MA5Data;//设置5日MA5前数据
        _this.option.chartOption.series[3].data = MA10Data;//设置10日MA10前数据
        _this.option.chartOption.series[4].data = MA30Data;//设置30日MA30前数据
        _this.option.chartOption.tooltip.formatter = function(params){
            for(var o = 0,len = params.length;o < len; o++ ){
                if(params[o].seriesName == 'MA5'){
                    MA5ToolTipValue = params[o].value;
                }else if(params[o].seriesName == 'MA10'){
                    MA10ToolTipValue = params[o].value;
                }else if(params[o].seriesName == 'MA30'){
                    MA30ToolTipValue = params[o].value;
                }
            }
            var tooltipData = KData[params[0].dataIndex];
            var content ="<p>"+params[0].axisValue+"</p>"
                +"<p>开盘价："+tooltipData[0]+"</p>"
                +"<p>收盘价："+tooltipData[1]+"</p>"
                +"<p>最低价："+tooltipData[2]+"</p>"
                +"<p>最高价："+tooltipData[3]+"</p>"
                +"<p>交易量："+tooltipData[4]+"</p>"
                +"<p>MA5："+MA5ToolTipValue+"</p>"
                +"<p>MA10："+MA10ToolTipValue+"</p>"
                +"<p>MA30："+MA30ToolTipValue+"</p>"
                +"<p>涨幅："+Math.round(tooltipData[5]*100)/100 +"%"+"</p>";
            return content;
        };//设置提示框 数据
        _this.option.chartOption.series[0].itemStyle.normal = {
            color: function(params) {
                var colorList;
                if (KData[params.dataIndex][1]>KData[params.dataIndex][0]) {
                    colorList = '#ef232a';
                } else {
                    colorList = '#14b143';
                }
                return colorList;
            }
        };//设置交易量涨跌颜色
        this.option.myChart.setOption(this.option.chartOption);
    };
    //动态数据请求
    KCharts.prototype.dynamicData = function(){
        var _this = this;
        _this.option.setIntervalMinute = setInterval(function(){
            //$.ajax({
            //    type:'GET',
            //    url:_this.option.dynamicUrl,
            //    dataType:'json',
            //    success:function(data){
            //        var dynamicData = data.data.data;
            //        _this.option.allData.push(dynamicData);
            //        _this.option.chartOption.series[0].data.push(formatMinuteData(dynamicData,4));
            //        _this.option.chartOption.series[1].data.push(formatMinuteData(dynamicData,2));
            //        _this.option.chartOption.series[2].data.push(formatMinuteData(dynamicData,3));
            //        _this.option.myChart.setOption(_this.option.chartOption);
            //    }
            //})；
        },10000);
    };
    //计算几天前的数据
    KCharts.prototype.calculateMA =function(dayCount, data){
        var result = [];
        for (var i = 0, len = data.length; i < len; i++) {
            if (i < dayCount) {
                result.push('-');
                continue;
            }
            var sum = 0;
            for (var j = 0; j < dayCount; j++) {
                sum += data[i - j][1];
            }
            result.push((sum / dayCount).toFixed(2));
        }
        return result;
    };
    //停止动态数据请求。
    KCharts.prototype.stopDynamicData = function(){
        clearInterval(this.option.setIntervalMinute);
    };
    //实例化图表
    KCharts.prototype.initChart = function(){
        this.getData();
    };
/**绘制K线图 end**/
/***echart数据 end***/


    var myChart;//用于图表实例化
    var minuteChart,fiveChart,kLineChart;

    //切换title
    function tabDetailModule(){
        var objArr = [
            {
                'index':0,
                'url':'../json/test.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'noAjax':true,
                'callback':function(me){
                    var html = template('marketTemp');
                    $('.lists').eq(me.opts.pageIndex).html(html);
                    myChart = echarts.init(document.getElementById('chartContainer'));//实例化图表
                    minuteChart = new minuteCharts('../json/minuteData.json',myChart,'动态数据URL');//分时图
                    fiveChart = new fiveCharts("../json/fiveLineData1.json",myChart);//五日图
                    kLineChart = new KCharts("../json/kLine.json",myChart);
                    minuteChart.initChart();
                    initChartModule();//初次实例化图表 切换按钮模块、
                    initAnalyzeModule();//初次实例化分析 切换按钮模块
                }
            },
            {
                'index':1,
                'url':'../json/noticeData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'noticeTemp'
            },
            {
                'index':2,
                'url':'../json/noticeData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'noticeTemp'
            },
            {
                'index':3,
                'url':'../json/calendarData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'calendar'
            },
            {
                'index':4,
                'url':'../json/roadShowData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'roadShow'
            },
            {
                'index':5,
                'url':'../json/interactionData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'interaction'
            },
            {
                'index':6,
                'url':'../json/interactionData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'interaction'
            },
            {
                'index':7,
                'url':'../json/stapleData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'stapleTemp'
            }
        ];
        var dropload = $('.detail-tab .tab-content').dropload({
            scrollArea:window,
            tabClass:'.detail-tab .item',
            tabArray:objArr
        });//创建下拉上拉加载控件
        dropload.unlock();//放开下拉上拉加载功能，默认是锁的
        $('.dropload-down').show();//放开下拉上拉加载功能，默认是锁的
    }
    //图表模块
    function initChartModule(){
        var chartTabHeader = $('.chartTab .tab-header');//图表头部切换按钮
        var chartTabBody = $('.chartTab .tab-body');//图表切换内容
        chartTitleEvents(chartTabHeader,chartTabBody)
    }
    //图表切换点击事件
    function chartTitleEvents(chartTabHeader,chartTabBody){
        chartTabHeader.delegate("a","click",function(){//图表切换
            var _index = $(this).index();
            if($(this).hasClass('cur')){
                return false;
            }
            $(this).addClass('cur').siblings('a').removeClass('cur');
            myChart.clear();
            minuteChart.stopDynamicData();
            switch (_index){
                case 0:
                    minuteChart.initChart();
                    break;
                case 1:
                    fiveChart.initChart();
                    break;
                case 2:
                    kLineChart.initChart();
                    break;
                case 3:
                    kLineChart.initChart();
                    break;
                case 4:
                    kLineChart.initChart();
                    break;
            }
        });
    }
    //分析数据模块
    function initAnalyzeModule(){
        var analyzeTabHeader = $('.analyzeTab .tab-header');/*分析数据块，tab标题*/
        var analyzeTabBody = $('.analyzeTab .tab-body');/*分析数据块，tab内容*/
        analyzeTableData("../json/analyzeSell.json","analyzeMarketTemp",analyzeTabBody.find('.tab-lists').eq(0));//初始化分析数据
        analyzeTitleEvents(analyzeTabHeader,analyzeTabBody);
    }
    //分析数据块，tab标题点击
    function analyzeTitleEvents(analyzeTabHeader,analyzeTabBody){
        analyzeTabHeader.delegate("a","click",function(){//分析数据块，tab标题点击
            var headerIndex = $(this).index();
            if($(this).hasClass('cur')){
                return false;
            }
            if(analyzeTabBody.find('.tab-lists')){
                var tabList = analyzeTabBody.find('.tab-lists');
                $(this).addClass('cur').siblings('a').removeClass('cur');
                tabList.hide().eq(headerIndex).show();
                _load(true);
                switch (headerIndex){
                    case 0://五档
                        analyzeTableData("../json/analyzeSell.json","analyzeMarketTemp",tabList.eq(headerIndex));
                        break;
                    case 1://明细
                        analyzeTableData("../json/analyzeDetail.json","analyzeMarketTemp",tabList.eq(headerIndex));
                        break;
                    case 2://分价
                        analyzeTableData("../json/analyzeMinutePrice.json","analyzeMarketTemp",tabList.eq(headerIndex));
                        break;
                    case 3://详细
                        analyzeTableData("../json/analyzeDataDetail.json","analyzeMarketTemp",tabList.eq(headerIndex));
                        break;
                }
            };
        });
    }
    //分析数据请求实例化template 添加到页面
    function analyzeTableData(url,tmpId,contentEle){
        $.ajax({
            type:'GET',
            url:url,
            dataType:'json',
            success:function(data){
                var _html = template(tmpId,data);
                contentEle.html(_html);
                _load(false)
            }
        })
    }


    //入口
    function initial(){
        new FastClick(document.body);
        tabDetailModule();//顶部 行情、公告等切换
    }


