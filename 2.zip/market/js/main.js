//切换标题
var droploadTab;
function titleTab(){
    var objArr = [{
        'index':0,
        'url':'json/test.json',
        'pageIndex':0,
        'pageSize':20,
        'loading':false,
        'tabLoadEnd':false,
        'template':'list'
    },
        {
            'index': 1,
            'url': 'json/test.json',
            'pageIndex': 0,
            'pageSize': 20,
            'loading': false,
            'tabLoadEnd': false,
            'template': 'list'
        },
        {
            'index': 2,
            'url': 'json/test.json',
            'pageIndex': 0,
            'pageSize': 20,
            'loading': false,
            'tabLoadEnd': false,
            'template': 'list'
        },
        {
            'index': 3,
            'url': 'json/test.json',
            'pageIndex': 0,
            'pageSize': 20,
            'loading': false,
            'tabLoadEnd': false,
            'template': 'list'
        },
        {
            'index': 4,
            'url': 'json/test.json',
            'pageIndex': 0,
            'pageSize': 20,
            'loading': false,
            'tabLoadEnd': false,
            'template': 'list'
        },
        {
            'index': 5,
            'url': 'json/test.json',
            'pageIndex': 0,
            'pageSize': 20,
            'loading': false,
            'tabLoadEnd': false,
            'template': 'list'
        }];

    droploadTab = $('.content').dropload({
        scrollArea:window,
        tabClass:'.tab .item',
        tabArray:objArr
    });//创建下拉上拉加载控件
    droploadTab.unlock();//放开下拉上拉加载功能，默认是锁的
    $('.dropload-down').show();//放开下拉上拉加载功能，默认是锁的

}

//内容手指动作
function contentEvents(){
    var touchLen = {};//存储横向的滑动坐标
    var contentDiv = $('.content');
    contentDiv.on('touchstart',function(e){
        if(!droploadTab.loading){
            if(!e.touches){
                e.touches = e.originalEvent.touches;
            }
            touchLen._startX = e.touches[0].pageX;
            if($(e.target).parents().hasClass('list-content')){
                touchLen._isListContent = true;
                touchLen._listContentUl = $('.list-content ul');
                touchLen._currentMarginLeft = parseInt(touchLen._listContentUl.css('left'));
            }
        }
    });//记录滑动的横向初始值
    contentDiv.on('touchmove',function(e){
        if(touchLen._isListContent){
            if(!droploadTab.loading){
                if(!e.touches){
                    e.touches = e.originalEvent.touches;
                }
                var _curX = e.touches[0].pageX;
                var _moveX = _curX - touchLen._startX;
                touchLen._listContentUl.css({'left':touchLen._currentMarginLeft + _moveX+'px'});
            }
        }
    });//进行翻页操作
    contentDiv.on('touchend',function(e){
        if($(e.target).parents().hasClass('list-content')) {
            var moveListContentUl = parseInt($('.list-content ul').css('left'));
            if(moveListContentUl>0){
                touchLen._listContentUl.animate({'left':0})
            }else if(moveListContentUl < -125){
                touchLen._listContentUl.animate({'left':-125})
            }
            touchLen = {}
        }

    });//滑动放开时横向值
    contentDiv.delegate('li','click',function() {
        //var _url = $(this).attr("detail-url");
        //window.open(_url);
        _nativeOpenHtml('module/market/view/detail.html');
    });
}



//实例化入口
function initial(){

    titleTab();
    contentEvents();
};
