/**
 * Created by XuLin on 2017/3/14.
 */

    //实例化标题切换
    function titleTab(){
        var objArr = [{
            'index':0,
            'url':'../interaction/json/interactionData.json',
            'pageIndex':0,
            'pageSize':5,
            'loading':false,
            'tabLoadEnd':false,
            'template':'eInteraction',
            'callback':function(me){
                var html = template('eInteraction');
                $('.lists').eq(me.opts.pageIndex).html(html);
                initInteractionList()
            }
        },
            {
                'index':1,
                'url':'json/roadShowData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'roadShow'
            },
            {
                'index':2,
                'url':'json/roadShowData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'roadShow'
            },
            {
                'index':3,
                'url':'json/roadShowData.json',
                'pageIndex':0,
                'pageSize':5,
                'loading':false,
                'tabLoadEnd':false,
                'template':'roadShow'
            }];

        var dropload = $('.content').dropload({
            scrollArea:window,
            tabClass:'.tab .item',
            tabArray:objArr
        });//创建下拉上拉加载控件
        dropload.unlock();//放开下拉上拉加载功能，默认是锁的
        $('.dropload-down').show();//放开下拉上拉加载功能，默认是锁的

    }

    //E互动 模块实例化
    function initInteractionList(){
        var analyzeTabHeader = $('.interaction-tab .tab-header');/*分析数据块，tab标题*/
        var analyzeTabBody = $('.interaction-tab .tab-body');/*分析数据块，tab内容*/
        interactionListData("../interaction/json/interactionData.json","answer",analyzeTabBody.find('.tab-lists').eq(0));//初始化分析数据
        interactionListEvents(analyzeTabHeader,analyzeTabBody);
    }
    //E互动，tab标题点击
    function interactionListEvents(analyzeTabHeader,analyzeTabBody){
        analyzeTabHeader.delegate("a","click",function(){//分析数据块，tab标题点击
            var headerIndex = $(this).index();
            if($(this).hasClass('cur')){
                return false;
            }
            if(analyzeTabBody.find('.tab-lists')){
                var tabList = analyzeTabBody.find('.tab-lists');
                $(this).addClass('cur').siblings('a').removeClass('cur');
                tabList.hide().eq(headerIndex).show();
                _load(true);
                switch (headerIndex){
                    case 0://答复
                        interactionListData("../interaction/json/interactionData.json","answer",tabList.eq(headerIndex));
                        break;
                    case 1://问题
                        interactionListData("../interaction/json/interactionData.json","question",tabList.eq(headerIndex));
                        break;
                    case 2://发布
                        interactionListData("../interaction/json/roadShowData.json","companyPublish",tabList.eq(headerIndex));
                        break;
                    default:
                        break;
                };
            };
        });
    }
    //E互动数据请求实例化template 添加到页面
    function interactionListData(url,tmpId,contentEle){
        $.ajax({
            type:'GET',
            url:url,
            dataType:'json',
            success:function(data){
                var _html = template(tmpId,data);
                contentEle.html(_html);
                _load(false)
            }
        })
    }


    function initial(){
        titleTab();
    }